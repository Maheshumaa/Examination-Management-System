<?php
$dbuser="root";
$dbpass="";
$host="localhost:3306";
$dbname = "srs2";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);

?>