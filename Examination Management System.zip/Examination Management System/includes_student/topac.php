

  <nav class="navbar top-navbar bg-white box-shadow">
            	<div class="container-fluid">
                    <div class="row">
                        <div class="navbar-header no-padding">
                			<a class="navbar-brand" href="dashboard.php">
                		Examination management system
                			</a>
                          
                        
                		</div>
                        <!-- /.navbar-header -->

                            <!-- /.nav navbar-nav -->

                		
                            
                	
                		</div>
                		<!-- /.navbar-collapse -->
                    </div>
                    <!-- /.row -->
            	</div>
            	<!-- /.container-fluid -->
            </nav>
</div>